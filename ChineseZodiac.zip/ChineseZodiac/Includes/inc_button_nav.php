<nav>
	<a href="../index.php">Home Page</a> |
	<a href="#">Site Layout</a> |
	<a href="#">Control Structure</a> |
	<a href="#">String Function</a> |
	<a href="#">Web Forms</a> |
	<a href="#">Midterm Assessment</a> |
	<a href="#">State Information</a> |
	<a href="#">User Templates</a> | 
	<a href="#">Final Project</a>
</nav>