<?php
include ("home_links_bar.inc")
	?>

	<p>PHP is a server side scripting language. That means its processing happens in the server by consuming server’s resources and sends only the output to the client. PHP can also be used as a language for Command line Scripting and Desktop applications. But it’s widely used for web applications.</p> 

	<p>PHP Web Development Makes Well-Organized and lucrative Websites. PHP is a coding technology invented for making applications, forms, and more as well as web development and can be easily set in into HTML. PHP technology runs on a web server, the programming of PHP technology proceeds as the input and output is the formation of the web forms. The coding tool is also applied for command-line programming and client-side GUI apps. It has been organized on scores of web servers, platforms and OS systems. It is also functional with scores of DBMS. The inclusive resource is on hand to the people at no cost. The website owners or developers can make; alter codes as per their standard uses.</p>
