<html>
  <head>
    <title></title>
    <style >
		ul, a {
			text-decoration: none;
			list-style-type: none;
			color: green;
		}
	</style>
  </head>
  <body>
  <div>
    <ul>
       <li><a href="index.php?page=home_page&section=php">PHP</a></li>
       <li><a href="index.php?page=home_page&section=zodiac">Chinese Zodiac</a></li>
    </ul>
  </div>
  </body>
</html>