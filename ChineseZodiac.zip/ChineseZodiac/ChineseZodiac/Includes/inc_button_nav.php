<nav>
	<a href="index.php?page=home_page">Home Page</a> |
	<a href="index.php?page=site_layout">Site Layout</a> |
	<a href="index.php?page=control_structures">Control Structure</a> |
	<a href="index.php?page=string_functions">String Function</a> |
	<a href="index.php?page=web_forms">Web Forms</a> |
	<a href="index.php?page=midterm_assignment">Midterm Assessment</a> |
	<a href="index.php?page=state_information">State Information</a> |
	<a href="index.php?page=user_templates">User Templates</a> | 
	<a href="index.php?page=final_project">Final Project</a>
</nav>
