<?php
include ("home_links_bar.inc")
	?>

	<h1>The Chinese Zodiac</h1>

<p>The Chinese Zodiac, known as Sheng Xiao in Chinese, is based on a twelve-year cycle. Each year in that cycle is related to an animal sign. These animal signs are the rat, ox, tiger, rabbit, dragon, snake, horse, sheep, monkey, rooster, dog and pig. It is calculated according to the Chinese lunar calendar. The doctrine of the twelve signs of the zodiac emerged during the Han dynasty, which makes it more than 2000 years old. The signs of the Chinese zodiac are also widespread in China's neighboring countries.</p>


<p>The Chinese believe the animal ruling one's birth year has a profound influence on personality, and destiny. The saying is: "This animal hides in your heart." The Chinese New Year's Eve is usually celebrated at the end of January or in February.</p>
 
<p>Unlike Western astrology, it does not look the heavenly constellations or planets to predict one's destiny. Rather, Chinese astrology deals with divining sciences of wuxing or the five elements (earth, fire, water, metal, wood), Yin and Yang, Chi, and the cycles of time. The Chinese horoscope isn't used for fortunetelling but provides information about a person's character, talents or biases.</p>

<p>Legend has it that inception of the Chinese zodiac signs began when the Buddha beckoned all the animals to bid him farewell before his departure from the Earth. Only twelve arrived at his summoning, and so those were given a place of honor in a year being named after each.</p>
