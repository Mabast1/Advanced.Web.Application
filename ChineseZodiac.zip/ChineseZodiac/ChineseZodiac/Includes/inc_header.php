<header>		
	<h2>Chinese Zodiac</h2>
	<h3>A code demonstration for PHP</h3>
	<h1>
		<img height="200px" src="http://www.animatedimages.org/data/media/1055/
		animated-chinese-zodiac-image-0009.gif" 
		border="0" alt="animated-chinese-zodiac-image-0009"/>
	</h1>
</header>